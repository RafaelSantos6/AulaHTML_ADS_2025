//for
// for (i = 0; i < 10; i++) {
//     console.log("For: ", i);
// }
// i = 0;

//while
// while (i < 10) {
//     console.log("While: ", i);
//     i++;
// }

//do while
// do {
//     console.log("Do While: ", i);
//     i++;
// } while (i <= 10);

//Arrays
// var frutas = ["banana", "maçã", "laranja", "uva"];

// for (i = 0; i < frutas.length; i++) {
//     console.log("Fruta: ", frutas[i]);
// }

// var arrPrato = new Array("arroz", "feijão", "carne", "salada");

// for (i = 0; i < arrPrato.length; i++) {
//     console.log("Prato: ", arrPrato[i]);
// }

//Push e Pop

// for (i = notas.length-1; i >= 0; i--) {
//     console.log("Nota: ", notas[i]);
// }

// var notas = [7, 8, 6, 9, 5];
// notas.push(10);
// notas.push(4);
// notas.pop();

//let Carros

// let carros = {
//     modelo: "A3",
//     ano: 2020,
//     cor: "Prata"
// }

// let carro2 = {
//     modelo: "Civic",
//     ano: 2022,
//     cor: "Preto"
// }

// console.log(carros["ano"]);
// carros["ano"] = 2021;
// console.log(carros.ano);

